const jobs = require('./jobs');
const snippets = require('./snippets');


module.exports = {
    jobs,
    snippets
}