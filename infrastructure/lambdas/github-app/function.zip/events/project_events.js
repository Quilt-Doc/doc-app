


// "project_card" event

/* Expected fields for API call
    cardId,
    cardNote,
    cardColumnId,
    cardCreatedAt,
    cardUpdatedAt,
    cardContentUrl
*/
const handleProjectCardEvent = async (backendClient, event, githubEvent, logger) => {


    await logger.info({source: 'github-lambda',
                        message: `Received event.body: ${JSON.stringify(event.body)}`,
                        function: 'handleProjectCardEvent'});

    var cardId = event.body.project_card.id;
    var cardNote = evnet.body.project_card.note;
    var cardColumnId = event.body.project_card.column_id;
    var cardCreatedAt = event.body.project_card.created_at;
    var cardUpdatedAt = event.body.project_card.updated_at;

}


module.exports = {
    handleProjectCardEvent
}