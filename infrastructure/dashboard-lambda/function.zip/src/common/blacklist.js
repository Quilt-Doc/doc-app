const blacklist = ["renovate-bot", "technote-space", "sw-yx"];

module.exports = blacklist;
