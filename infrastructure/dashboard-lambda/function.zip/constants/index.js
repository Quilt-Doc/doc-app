const jobs = require('./jobs');
const snippets = require('./snippets');
const checks = require('./checks');

module.exports = {
    jobs,
    snippets,
    checks
}